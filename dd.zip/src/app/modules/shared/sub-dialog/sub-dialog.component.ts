import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-dialog',
  templateUrl: './sub-dialog.component.html',
  styleUrls: ['./sub-dialog.component.scss']
})
export class SubDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
