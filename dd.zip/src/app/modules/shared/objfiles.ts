export interface UserInterface {
    userName: string;
}
