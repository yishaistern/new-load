import { SubDialogComponent } from '../shared/sub-dialog/sub-dialog.component';
import { SecondSecondComponent } from '../second-module/second-second/second-second.component';
export const compObj = {
    aa : {
        key: 'aa',
        component: SubDialogComponent
    },
    bb : {
        key: 'bb',
        component: SecondSecondComponent
    }
};
