import { HostDynamicDirective } from './host-dynamic.directive';

describe('HostDynamicDirective', () => {
  it('should create an instance', () => {
    const directive = new HostDynamicDirective();
    expect(directive).toBeTruthy();
  });
});
