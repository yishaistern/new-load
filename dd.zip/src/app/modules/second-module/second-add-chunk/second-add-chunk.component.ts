import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-add-chunk',
  templateUrl: './second-add-chunk.component.html',
  styleUrls: ['./second-add-chunk.component.scss']
})
export class SecondAddChunkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
